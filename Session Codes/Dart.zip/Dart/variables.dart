void main()
{
  String name = 'Prajwal';
  int age = 19;
  print( name);
  print(age);

  const pie = 3.14 ;
  const area = pie * 12 * 12;
  print("The area is :$area");
  print("The value of pie is :$pie");
}
