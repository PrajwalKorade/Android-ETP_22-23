// checking the datatype of the variable.
void main() 
{
  num age = 19;
  num height_in_cm = 186.45;
  print(age.runtimeType);
  print(height_in_cm.runtimeType);
}