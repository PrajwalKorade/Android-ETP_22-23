import 'dart:io';
void main() 
{
  stdout.write('Enter ur name');
  var name = stdin.readLineSync();
  print(name);
}